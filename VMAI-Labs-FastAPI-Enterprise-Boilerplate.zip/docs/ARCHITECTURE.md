# Architecture
Routers -> Services -> Database
