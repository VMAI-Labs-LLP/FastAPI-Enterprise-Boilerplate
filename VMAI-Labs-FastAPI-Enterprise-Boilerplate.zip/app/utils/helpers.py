def ping(): return 'pong'
